# PredicateImpact / SkillLineage Research Artifact

Current paper (2026-09-06): **From Skill-Level to Predicate-Level: Budgeted
Regression Test Selection for Evolving LLM Agent Skills**.

This is the first positive paper produced from the Agent Skill lifecycle
research matrix. It studies a practical maintenance problem: after a small
conditional part of a skill changes, which previously passing interactive
tests should run first when replay is expensive?

PredicateImpact maps successful traces to skill-internal action predicates and
prioritizes tests that covered the changed predicate. At a three-test budget:

| Confirmation | Killable changes | PredicateImpact | Skill-family random | Absolute lift | One-sided conditional p |
|---|---:|---:|---:|---:|---:|
| R23 deletion, untouched roster | 64 | 1.0000 | 0.5561 | 0.4439 | 1.65e-19 |
| R24 three operators, disjoint roster | 115 | 1.0000 | 0.5567 | 0.4433 | 8.29e-35 |

The effect appears separately in ALFWorld and ScienceWorld and for deletion,
same-kind argument substitution, and adjacent-order swap. All 491 native
mutation replays match their healthy initial states and have no technical
errors. A stronger ablation that randomizes only within the exact predicate
coverage set also scores 1.0000, so the supported contribution is the finer
coverage granularity, not the proposed within-set tie-breaker.

## Manuscripts

- English source/PDF: `paper/predicate_rts/en/main.tex` and
  `paper/predicate_rts/en/main.pdf`
- Chinese source/PDF: `paper/predicate_rts/zh/main.tex` and
  `paper/predicate_rts/zh/main.pdf`
- Frozen protocols and raw records: `revisions/22_predicate_impact_testing/`
  through `revisions/26_coverage_noise_sensitivity/`
- Derived tables and figures: `results/regression_testing/` and
  `results/figures/`
- Claim boundary: `research/PREDICATE_RTS_CLAIM_EVIDENCE.md`
- Submission status: `research/PREDICATE_RTS_SUBMISSION_READINESS.md`
- Audited machine/software snapshot: `research/PREDICATE_RTS_RUN_ENVIRONMENT.md`

The earlier recovery manuscript remains under `paper/en/` and `paper/zh/`.
It honestly reports that lineage-guided recovery did not improve 288 native
model-task pairs. It is retained as a separate negative-result study and as
the development history that motivated the regression-testing pivot; it is
not the current submission.

## Repository Layout

```text
01_skilllineage/
|-- analysis/                         Submission analysis and figures
|-- artifacts/                        Reproducibility bundle builders/checksums
|-- environment/                      No-Docker AutoDL setup
|-- paper/predicate_rts/en/            Current English manuscript and PDF
|-- paper/predicate_rts/zh/            Current Chinese manuscript and PDF
|-- research/                         Protocol, evidence, and claim boundaries
|-- revisions/22_predicate_impact_testing/
|-- revisions/23_reserved_confirmation/
|-- revisions/24_operator_transfer_confirmation/
|-- revisions/25_real_skill_change_audit/
|-- revisions/26_coverage_noise_sensitivity/
|-- results/                          Generated tables and figures
|-- submission/                       Journal-facing editable templates
|-- src/                              Shared implementation
`-- tests/                            Network-free tests
```

## Verify

The archived results, audits, figures, and both PDFs can be checked without a
GPU after retrieving the hash-pinned 7.5 MB ScienceWorld JAR:

```bash
bash research/validation/fetch_scienceworld_130.sh
bash artifacts/verify_predicate_rts.sh
```

The core confirmation does not call an LLM and does not use the installed RTX
3090. A CPU machine with Java 17, 16 GB RAM, and the upstream ALFWorld data is
sufficient; the reported AutoDL container had a 20-core quota and 90 GiB memory
limit on an AMD EPYC 7642 host. See
`REPRODUCE.md` for environment setup and clean-room rerun commands.

## Evidence Boundary

The result is reliable for the two frozen mutation benchmarks and their three
edit operators. It does not establish automatic localization in arbitrary
free-form `SKILL.md` files or population-level benefit on naturally faulty
production commits. The public-repository audit only establishes that
deletion-, replacement-, and relocation-shaped edits occur in real skill
histories. These limits are stated in the abstract, discussion, threats to
validity, and conclusion.
